%% V2X WORKSHOP 
% Este ejemplo muestra cómo modelar y simular una negociación de semáforos
% utilizando comunicación de vehículo a todo (V2X) basado en un ejemplo 
% de Matlab con el nombre "TrafficLightNegotiationWithV2X". 
% Este ejemplo utiliza los modos de comunicación de vehículo a vehículo 
% (V2V) y de vehículo a infraestructura (V2I) de V2X.

%% Introduction
% Un sistema de negociación de semáforos toma decisiones apropiadas en 
% una intersección según el estado actual del semáforo y el de otros
% vehículos cercanos. V2V y V2I son tecnologías de comunicación inalámbrica
% que transmiten información esencial sobre los estados de otros vehículos
% y el estado de una señal de semáforo a un vehículo ego. Estas tecnologías
% mejoran la capacidad perceptiva de los vehículos, permitiéndoles
% gestionar eficazmente la negociación de semáforos. La información
% recibida a través de los sistemas V2V y V2I es utilizada por el
% componente lógico de decisión de una aplicación de conducción
% automatizada. Este componente reacciona a la información sobre el estado
% del semáforo y los vehículos circundantes y proporciona entradas
% necesarias al controlador para guiar el vehículo de manera segura.

% Copiemos el TestBench.


addpath(fullfile(matlabroot,"toolbox","driving","drivingdemos"));
helperDrivingProjectSetup("TrafficLightNegotiationWithV2X.zip",workDir=pwd);
open_system("TrafficLightNegotiationWithV2XTestBench");

%% Visualización del escenario
% Escenario vehicular caracterizado por una intersección y un semáforo
plot_v2xscn(scenario)

%% Scenario_01 con/sin comunicación V2X y con diferentes rangos de calidad.
% Se analizará el escenario de una intersección donde el vehículo ego se
% encuentra detrás de un vehículo pesado. Se examinarán condiciones con
% y sin comunicación V2V (con el vehículo líder) y V2I (con el semáforo)
% para evaluar su impacto.

helperSLTrafficLightNegotiationWithV2XSetup(ScenarioFcnName="scenario_01_TLNWithV2X_LeftTurn_With_Lead",Range = 20);
mpcverbosity("off");
sim("TrafficLightNegotiationWithV2XTestBench");

%% Graficar los resultados
helperTLNWithV2XResults(logsout)

%% Scenario_03 vehículo cruzado infraccionando el semáforo
% Se estudiará un escenario en el que un vehículo se encuentra en
% la intersección del semáforo y no respeta la señalización.

helperSLTrafficLightNegotiationWithV2XSetup(ScenarioFcnName="scenario_02_TLNWithV2X_LeftTurn_With_CrossOver",Range = 0);
sim("TrafficLightNegotiationWithV2XTestBench");

%% Graficar los resultados
helperTLNWithV2XResults(logsout)

%% Escenario de prueba
% La simulación involucra un vehículo de gran tamaño y otro que cruza la
% intersección sin respetar el semáforo. Variables como la velocidad del 
% vehículo principal, el rango de calidad de la recepción y la trayectoria 
% vehicular son ajustables. Al finalizar la simulación, se presentan los 
% resultados que muestran la distancia recorrida en el eje y y el valor 
% del rango de calidad. El objetivo es encontrar valores que maximicen 
% la distancia recorrida por el vehículo sin infringir las leyes de 
% tránsito ni causar accidentes, además de optimizar el rango de calidad 
% de la comunicación vehicular.

% set the ego vehicle speed (max 16)
speed=9;
% set the ego V2X range
v2x_range=0;
% set vehicle lane ("left" or "right")
lane="left";

workshop_Setup(ScenarioFcnName="scenario_01_workshop",Range = v2x_range, ego_speed = speed, ego_lane=lane);
sim("TrafficLightNegotiationWithV2XTestBench");

% Print the distance in y-axis and the range
fprintf('The distance in y is: %.2f\n', egoVehicle.Position(2));
fprintf('The range is: %.2f\n', v2x_range);

%%
% Plot the results.
helperTLNWithV2XResults(logsout)